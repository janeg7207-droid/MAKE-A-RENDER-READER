SelectionLoop experimental companion — first version

Requires Windows x64 WWE 2K26 with CakeHook and the exact original
MovingRenders 4.21 supplied with Gorilla Studio. The installer verifies
that original module; it does not replace or edit its bytes.

1. Update Gorilla Studio to helper 1.7.13 using Update app or the update ZIP.
2. Close WWE. Extract this entire ZIP. Run GorillaSelectionLoopInstaller.exe.
3. Choose WWE2K26_x64.exe, then Install and enable.
4. In Studio, tick Roster selection and Match card, choose
   Play once + flash freeze, then MAKE and Install into the game again.
5. Restart WWE. Keep the generated .gmr.selection-loop.json next to its GMR.

Selection loops only the clean moving portion before the flash.
The match card retains the original flash-freeze ending. Freeze renders
contain a shortened taunt; this plugin cannot recover its missing remainder
or guarantee a seamless loop. Old GMRs require a fresh MAKE. Extra-ID aliases
retain native behavior. Existing screen setup and Discovery bake still apply.
This companion does not repair unsupported match-card layouts.

The downloaded configuration starts disabled. Use the installer to opt in.
It verifies the DLL and original compatibility, records first-install backups,
and enables only this companion. Uninstall restores/removes only unchanged
owned files; changed files are preserved with an explanation. The game must
be closed. The regular app updater does not install this optional companion.

Sources and exact native mappings are verified before activation. Unsupported
versions, missing policies and ambiguous claims retain native behavior.
Changes to GorillaRenders during gameplay disable overrides until restart.
Diagnostics: <game>/Plugins/WWE2K26_SelectionLoop.log.

Portable source-policy, installer, original instruction and actual assembly
checks passed. The x64 Windows binary is cross-built; Windows loader,
CakeHook/MinHook installation and in-game playback are not tested here.
Treat this as an optional experimental build. Source is included in the
main Source ZIP at src/SelectionLoopPlugin and tools/GorillaSelectionLoopInstaller.
MinHook v1.3.4 is used under its included BSD-2-Clause license.
