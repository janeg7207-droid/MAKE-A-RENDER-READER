GORILLA STUDIO v1.0.2 - DISCOVERY ROSTER EXPERIMENT

START
1. Keep this experimental build separate from your original installation.
2. Open GorillaStudio.exe and sign in as usual.
3. Click LOAD DISCOVERY ROSTER below the original Browse / Find buttons.
4. Choose your extracted discovery_data folder. It must contain Characters
   and Roster\CharProfileTable.jsfb. Choosing Characters or Roster works too.
5. Search, select a superstar, then click LOAD SELECTED WRESTLER.
6. Continue with Preview / Make / Install in the updated v1.0.2 interface.

The app remembers this Discovery root in its original settings. The existing
Find by name feature can also list the mod folders at that location.
You can alternatively drop a Discovery folder or one character folder.
Character folder names do not need leading numbers; select the correct ID
and name in the picker. Original character folders are not renamed/copied.

JSON / JSFB ONLY
Use Load roster file in the picker to import JSON or CharProfileTable.jsfb.
rosters\Discovery_roster.json contains your 10 supplied named characters.
Example JSON: [{"id":1506,"name":"Flammer"}]
JSFB must remain beside its companion Characters directory. This experiment
reads known names/IDs from available character folders, not every localized
name in the whole binary profile table. Stock-game search remains native.
Saved additions survive reopening the same roster, and chosen model folders
are remembered in collection mode. A real wrestler ID is needed internally.

REQUIREMENTS
Windows .NET Framework 4.8, Blender 5.2 or newer, WWE 2K26 with the original
plugin requirements. Keep GorillaStudio.NameFolders.dll beside the EXE.
Plain-name links require a local Windows drive supporting NTFS junctions.
Roster data/links: %LOCALAPPDATA%\GorillaStudio\NameFolders

TESTED
- 46 importer, name, path and roster-session checks passed.
- v1.0.2 engine loaded all 10 supplied character IDs and attire models.
- Added plain-name Flammer Experimental loaded with ID1506, correct female
  flag and picture hash E4A5CD759AD62903.
- Original user inputs remain unchanged (hash verified).
- Only the app constructor and folder-loading method changed. Other methods,
  sign-in/licensing and original resources remain intact.

REMAINING VALIDATION
The render attempt reached v1.0.2's stock-body extraction, then stopped
because the build machine has no installed WWE 2K26 files / Oodle DLL.
Complete rendering needs your game installation and was not validated here.
The Windows GUI and junction API also still need a Windows smoke test;
original-engine data tests ran under Python3.14 on Linux with equivalent
folder links. See TEST_RESULTS.json for the actual recorded outcomes.
Hogan2002 (109) and ReyMysterio2019 (123) have no roster-picture links in the
supplied table, as reported by the original engine.

SMALL UPDATE ZIP
Apply ONLY to a separate copy of GorillaStudio v1.0.2. Keep all its existing
engine, data, plugin and other files. Do not apply to the older v1.0 build.
The full experimental ZIP is standalone apart from game/Blender requirements.
