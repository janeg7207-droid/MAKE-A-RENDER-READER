# Gorilla Studio v1.0.2 — Discovery Roster Experiment

Select a wrestler from the roster to load their matched model and default attire automatically, then choose a taunt and use **Preview → MAKE → Install**. The loader reads Discovery's current profiles, names and exact character asset mappings, including newly added IDs. It remembers your extracted mod collection and manual choices. **Fast Preview**, **Fast MAKE**, and a preview cache reduce repeated rendering work. The helper is version **1.6.0**; the original application is Gorilla Studio v1.0.2.

## Download

- [Full program ZIP](https://github.com/janeg7207-droid/MAKE-A-RENDER-READER/raw/refs/heads/main/downloads/GorillaStudio_v1.0.2_Discovery_Experimental.zip)
- [Small update ZIP for an existing v1.0.2 copy](https://github.com/janeg7207-droid/MAKE-A-RENDER-READER/raw/refs/heads/main/downloads/GorillaStudio_v1.0.2_Discovery_Experimental_Update.zip)
- [Source ZIP](https://github.com/janeg7207-droid/MAKE-A-RENDER-READER/raw/refs/heads/main/downloads/GorillaStudio_v1.0.2_Discovery_Experimental_Source.zip)

Extract the small update into the folder containing GorillaStudio.exe in a **separate copy of v1.0.2**. Replace the executable and helper DLL together, keeping the original engine, data and plugin folders. It also updates the previous experimental v1.0.2 build. It does not apply to v1.0.

The full program ZIP uses Git LFS. Use the download link above, or install Git LFS before cloning. SHA-256 checksums are in downloads.

## Use

1. Keep your extracted Discovery folders together:

       discovery_data/
         Roster/CharProfileTable.jsfb
         Characters/CharacterMapping.jsfb
         Characters/<your character folders>/
         Sdb/ENG.sdb
         MoveData/CAMMoveData.jsfb
         Animation/<your animation assets>/

2. Set **Discovery data…** to your extracted discovery_data folder once, keeping its companion folders together. Selecting Characters or Roster also works. **Roster file…** opens an existing JSON/JSFB roster and remembers that file. **Select wrestler…** opens the current roster directly; it can also open saved or bundled names without asking for a model folder first.
3. If your models are stored outside Discovery, click **Set model library…** once and select the main folder containing your extracted wrestler mods. It scans nested folders, attaches unique matching models, and remembers this location for the roster. You can paste a path, drag a folder into the location box, or browse using Explorer's address bar and search. Keep model files extracted; the renderer uses .mcd models.
4. Search by name or ID, then **click the wrestler once**. The picker loads a verified mapped model, a saved choice, or a unique exact-name model, and closes. The renderer selects its default attire automatically. Multiple matching mod packs ask you to choose between those matches once and remember your choice. Missing files show a clear status; the normal roster path does not open a per-wrestler folder hunt. **Choose model folder…** remains available for an explicit override. Plain names need no numeric prefix. **Refresh data** rereads the roster and rescans remembered locations. Folder-to-wrestler manual assignment still requires an explicit choice.
5. Continue with the original Preview / Make / Install controls. Windows, .NET Framework 4.8, Blender 5.2 or newer, and the original WWE 2K26/plugin setup are required.

## Discovery taunts and previews

Keep the **entire extracted Discovery data folder together**, including MoveData and Animation. The loader reads actual taunt names and IDs from `MoveData/CAMMoveData.jsfb` and joins them to animation records in `.clips` containers and loose `.clip` files. A newer loose edited clip takes precedence over a container record. It converts supported body motion into the original engine's animation format automatically; no Python installation or separate animation browsing is required.

The uploaded data contains **1,584 named taunt variants**. It adds **194 playable motions**, for **1,088 available taunts** with the original library retained. This includes **Undisputed 2**, animation `62541a000`: 281 frames at 60 fps, about 4.68 seconds. The original library had excluded it through a pose-screening heuristic. Variations such as LA Parka 1, 2 and 3 keep their distinct animation files and renderer keys.

Select your wrestler, search for **Undisputed 2**, then click **Preview**. The first successful Preview also supplies that taunt's small browser preview using the actual rendered images. Later browsing reuses it, without another render. The selected wrestler's main Preview uses their loaded model and attire. Changed motions receive new cache keys so old animation or preview files cannot silently replace current Discovery data.

The supplied files lack matching body motion assets for **455 variants**. **45** more use older additional channel sections that this experimental decoder does not yet support. These entries are reported rather than added as playable animations; existing bundled versions remain available where present. The importer never substitutes another taunt. Discovery setup reports available, missing and unsupported counts. It rereads the current folder when selecting the roster, so newly added supported animations are picked up.

Generated animation data, working captures and previews live in a writable folder under `%LOCALAPPDATA%/GorillaStudio/NameFolders`, alongside the preview cache. The original Discovery files and application assets remain intact. Unchanged refreshes reuse decoded motion and keep the selected taunt.

## Faster previews and renders

Fast Preview and Fast MAKE are enabled initially. Click **Speed…** next to Preview to change either setting or restore the original quality.

| Operation | Original defaults | Faster mode | Calculated rendering work |
| --- | --- | --- | --- |
| Wrestler Preview | 384 × 384, 16 samples | 256 × 256, 8 samples | 77.8% fewer pixel-samples |
| MAKE GORILLA RENDER | 1024 × 1024, 64 samples | 1024 × 1024, 32 samples | 50% fewer samples |

These are work calculations, **not measured time savings**. Model loading, Blender startup, encoding, GPU load and other fixed costs still take time. Preview retains its animation frames and playback rate. Fast MAKE retains full output resolution and animation timing, with fewer lighting samples; untick it for the original shadow quality. Existing inherited renderer options remain in effect except for the faster mode's explicit overrides.

Unchanged previews reopen from an on-disk cache without starting Blender. Changes to character inputs, textures, roster context, taunt/settings, Blender/engine metadata or mode invalidate that cache. Cached images are separate copies, so another preview cannot overwrite them. Damaged or unreadable cache entries fall back to rendering. The cache retains at most 64 entries. Full MAKE always uses the original engine.

Automatic full rendering after Preview is off initially. This prevents a full render from occupying the GPU while browsing. Turn **Start MAKE automatically after Preview** back on in Speed… if preferred. Changing quality stops an existing automatic render before it can be reused with the wrong setting.

The small timer below Preview displays the actual request time, with initial model preparation separate. For an old/new comparison, load your wrestler, choose a taunt, click **Speed… → Compare old / new times**. Leave **Also compare full MAKE** checked to measure both operations. The comparison runs one warm-up, then original and faster previews and renders, bypassing preview cache hits. It reports seconds, seconds saved, percentage change and speed ratio; slower results are reported as slower. This takes several renders. Results and comparison files stay under `%LOCALAPPDATA%/GorillaStudio/NameFolders/benchmarks`; ordinary render output and installed game files are untouched. The latest text report is `performance-comparison.txt` in the NameFolders folder.

These are individual measurements in original-then-fast order, using a shared prepared model. The first full-resolution MAKE can require additional setup; GPU load and run order affect results. Real Windows/GPU timings have **not** been measured in this Linux build environment.

After adding characters, save your updated CharProfileTable.jsfb and Sdb/ENG.sdb, put their extracted models inside a remembered models folder, then click **Refresh data**. It rereads the current roster and names, rescans the model folders, and includes new IDs. For an imported JSON roster, Refresh data reloads that same JSON file during the current session. Renamed characters replace stale saved labels; conflicting saved model choices require selection. Reopening Discovery also rereads its current files.

A roster profile can exist without its model in the selected data. **Model files missing** means that the name and ID were read, but no matching extracted model has been located. Point the model library at the parent folder containing your actual mod folders once. The supplied Discovery archive itself contains ten extracted character models; the other profiles need their models from your collection or a verified installed-game mapping.

Existing explicit model associations remain authoritative. Fresh matches prefer the exact CharacterMapping asset-path hash, then exact names and proven stock mappings. Duplicate matches require your choice. A physical folder number is not enough to override a conflicting localized profile: the uploaded physical 109 Hollywood Hogan folder no longer loads as Karl Anderson's logical slot 109. Unassigned physical models remain in the separate model list. Verified installed-game models retain the original extractor. You can explicitly map any discovered model to another profile with **Use folder for another wrestler…**.

ENG.sdb supplies the readable character names. Keep your own current file in Sdb/ENG.sdb. Missing localized strings display as “Wrestler <ID>”; the loader never substitutes a localization key as a wrestler name.

Only **JSON and JSFB** are accepted by **Load roster file…**. SDB is read automatically as companion name data. JSON supports arrays such as [{"id":1506,"name":"Flammer"}], common roster wrappers, and name-to-ID or ID-to-name maps. Actual wrestler IDs must be 1–65535. The included rosters/Discovery_roster.json is a portable name/ID export; point the loader at your Discovery folder to discover its models.

Dropping a character folder also opens the picker, keeping that folder as the model source. The selected logical roster ID controls the target slot and render links; the physical source ID controls stock-body extraction. For example, the supplied mapping associates physical folder 312_CM_Punk with roster ID 1481.

Saved manual entries and model choices reopen with the same roster. Freshly scanned model mappings take precedence. Older saved folder-derived entries are refreshed to their actual mapped IDs. Settings and NTFS compatibility links are stored under %LOCALAPPDATA%/GorillaStudio/NameFolders. Original character folders keep their names and contents. Plain-name links require a local Windows drive supporting NTFS junctions.

## Validation

- The supplied data loads **1,457 roster profiles**, with **1,308 localized names**, and finds all **10 extracted model folders**. Eight model associations are proven by exact mapping hashes, Brock Lesnar matches by name, and one unmatched physical Hollywood Hogan model remains unassigned. Video examples NICK JACKSON '14 (204), DAX HARWOOD (211), and CASH WHEELER (213) match the uploaded SDB.
- **764 portable checks pass** across 17 suites, covering roster-first launches, actual model mappings, saved choices, default attire, motion decoding/import, preview capture, callback replay, model/texture changes, failed renders, full-MAKE cache bypass, original-quality opt-out, measured timing arithmetic, native access guards and benchmark output isolation. Detailed counts are included in TEST_RESULTS.json. Binding 1,457 profiles against 5,000 indexed model folders takes about 20 ms in the build environment; this is separate from rendering performance.
- Growth tests append valid new profiles and SDB strings to a separate copy of the actual data: **1,457 → 1,458 → 1,459** profiles. A copied real model binds to new logical ID 4000 with physical source 1506; edited JSON files reload new characters; high new ID 65527 preserves existing reserved IDs. Uploaded originals remain unchanged.
- Portable importer/session, binary mapping, and extraction-output tests cover profile decoding, malformed data, ambiguous paths, saved settings, legacy entries and explicit slot selection. Both the .NET Framework 4.8 helper and patcher build without warnings or errors.
- A copied real character in a plain-name folder remains visible before assignment, then loads and reopens with an explicit added roster entry. Original MCD bytes stay unchanged.
- The original v1.0.2 engine verifies physical 312 → logical 1481 and physical 123 → logical 910. It retains the original model/body source while using the selected profile's render links and gender. The 1481 case selects 148100_CM_PUNK_GM.
- A real render attempt loads the added Flammer model and reaches original stock-body extraction, then stops because this environment lacks WWE 2K26 / oo2core_9_win64.dll. Complete rendering and Windows GUI/junction interaction remain unverified.
- The original default-attire function is exercised on all ten uploaded model folders and direct-MCD compatibility layouts. The independent motion decoder matches a bundled animation's translations exactly and its quaternions within 0.000001. The unmodified original capture engine consumes the imported Undisputed 2 motion and produces 281 frames for a 175-bone skeleton, including 74 H helper bones. Full Blender image rendering remains unverified here.
- The patcher verifies a five-method allowlist: the window constructor, folder-loading state machine, Go state machine, process-launch state machine and automatic-render entry point. All other method bodies, authentication/licensing and managed/native resources are preserved. Engine binaries remain unchanged; faster detail is passed only to each applicable render process.

Detailed results are included in TEST_RESULTS.json inside the ZIPs.

## Build

Requires the .NET 8 SDK and the supplied original v1.0.2 release. Building on Linux is supported; running requires Windows.

    dotnet build src/GorillaStudio.NameFolders/GorillaStudio.NameFolders.csproj -c Release
    dotnet build tools/GorillaStudioPatcher/GorillaStudioPatcher.csproj -c Release
    dotnet run --project tests/RosterTests -c Release -- /path/to/discovery_data
    dotnet run --project tests/DiscoveryScannerTests -c Release -- /path/to/discovery_data /path/to/Sdb/ENG.sdb /path/to/original/data/gamepack/stock_index.json
    dotnet run --project tests/GameModelBridgeTests -c Release
    dotnet run --project tests/ModelLibraryTests -c Release -- /path/to/discovery_data
    dotnet run --project tests/ModelBindingTests -c Release
    dotnet run --project tests/RosterGrowthTests -c Release -- /path/to/discovery_data
    dotnet run --project tests/PreviewCacheTests -c Release
    dotnet run --project tests/PreviewProcessTests -c Release
    dotnet run --project tests/PreviewRenderBridgeTests -c Release
    dotnet run --project tests/RenderBenchmarkTests -c Release
    dotnet run --project tests/RosterLaunchTests -c Release -- /path/to/discovery_data
    dotnet run --project tests/RosterModelResolutionTests -c Release
    dotnet run --project tests/MappedModelLibraryTests -c Release -- /path/to/discovery_data
    dotnet run --project tests/AutomaticAttireTests -c Release
    dotnet run --project tests/DiscoveryTauntsTests -c Release -- /path/to/discovery_data/MoveData/CAMMoveData.jsfb
    dotnet run --project tests/DiscoveryMotionTests -c Release
    dotnet run --project tests/DiscoveryTauntLibraryTests -c Release -- /path/to/original/GorillaStudio /path/to/discovery_data /path/to/disposable-import-output
    dotnet tools/GorillaStudioPatcher/bin/Release/net8.0/GorillaStudioPatcher.dll /path/to/original/GorillaStudio.exe src/GorillaStudio.NameFolders/bin/Release/net48/GorillaStudio.NameFolders.dll /path/to/new/GorillaStudio.exe

Copy the original release's remaining files and the helper DLL into the new output folder. The patcher requires a new output path and verifies the original executable's supported layout.

The Python validators in tests use the original engine bytecode with CPython 3.14, NumPy 2.4.3 and Pillow. Run each with --help for arguments. validate_user_data.py performs an actual render attempt; validate_mapped_engine.py observes logical-slot handling and stops deliberately before game extraction. Neither script tests the Windows GUI.
